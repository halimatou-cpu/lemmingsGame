package views.panels;

import javax.swing.*;

public abstract class AbstractPanel extends JComponent {
}
