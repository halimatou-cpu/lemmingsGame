package models.fonctionnalities;

import models.Lemming;
import models.ModelContainer;
import models.Position;

public class WalkerState implements State {
    private int counter = 0;

    @Override
    public void action(Lemming lemming, ModelContainer container) {
        Position position = lemming.getPosition();
//manipuler isOnSupport pour faire reagir les obstacle, m'inspirer du feu 
        if (!container.getPlan().isOnSupport(lemming)) {
            position.setY(position.getY() + 1);

            if (counter++ > 3) lemming.setActive(false);

            return;
        }

        this.walk(lemming, container);
    }


    public void walk(Lemming lemming, ModelContainer container) {
        Position position = lemming.getPosition();
        Position casePosition = new Position(position.getX(), position.getY());

        if (position.getX() <= 0 ||
//                position.getX() >= container.getPlan().getCases()[0].length ||
        		position.getY() >= container.getPlan().getCases()[0].length  //||
//        				container.getPlan().isWall(position)
//        		container.getPlan().isWall(new Position(position.getX(),position.getY() /* -+1*/))
        		|| container.getPlan().nextCaseOf(casePosition)==null
        ) lemming.switchDirection();

        int seed = (lemming.hasDirectionLeft() ? -1 : 1);
//        Position nextCasePosition = new Position(position.getX() + seed, position.getY());
//        Position nextCasePosition = new Position(position.getX(), position.getY());

        if (container.getPlan().nextCaseOf(casePosition)==null) ;
//        	lemming.switchDirection();
//        	position.setX(lemming.getPosition().getX() +seed);
//        }
        else 
        	if (container.getPlan().nextCaseOf(casePosition).isEmpty() ) {
            position.setX(lemming.getPosition().getX() + seed);
//        	position.setX(lemming.getPosition().getY() + seed);
            this.counter = 0;
        } else {
            container.getPlan().moveUp(position);
            position.setX(lemming.getPosition().getX() + seed);
//            position.setX(lemming.getPosition().getY() + seed);
            this.counter = 0;
        }
    }
}
